#!/data/data/com.termux/files/usr/bin/bash

echo "🔧 자비스 설치 시작: Termux 최적화 모드"

# 필수 패키지 설치
pkg update -y
pkg install -y python git curl

# 디렉토리 생성
mkdir -p ~/jarvis

# 자비스 본체 이동 (jarvis.py는 별도 제공)
mv ~/storage/downloads/jarvis.py ~/jarvis/ 2>/dev/null

# 실행 파일 등록
echo 'python3 ~/jarvis/jarvis.py' > $PREFIX/bin/jarvis
chmod +x $PREFIX/bin/jarvis

# 자동 실행 등록
echo 'alias jarvis="python3 ~/jarvis/jarvis.py"' >> ~/.bashrc

echo "✅ 자비스 설치 완료. 이제 'jarvis' 명령어로 실행하세요."
