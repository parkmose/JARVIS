#!/bin/bash
pkg update -y
pkg install -y python git
pip install requests

mkdir -p ~/jarvis
cp config.json ~/jarvis/

cat <<EOF > ~/.termux/bin/jarvis
python ~/jarvis/jarvis.py
EOF

chmod +x ~/.termux/bin/jarvis
echo "✅ 자비스 설치 완료! 'jarvis' 명령어로 실행하세요."